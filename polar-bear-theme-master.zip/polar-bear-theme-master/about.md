---
layout: page
title: About
permalink: /about/
---
*Polar Bear* is a lightweight and customisable Jekyll Theme.

* Author: Camille Diez
* Github: http://github.com/diezcami
* Portfolio: http://diezcami.github.io